﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] list = { 12, 78, 67, 90 };
            int[] temp = list;
            Console.Write("orginal array");
            foreach (int i in list)
            {
                Console.Write(i + "");
            }
            Array.Reverse(list);
            Console.Write("reversed Array");
            foreach (int i in temp) {
                Console.Write(i + "");
            }
            Array.Sort(list);
            Console.Write("sorted array");
            foreach (int i in list)
            {
                Console.Write(i + "");
            }
            Console.ReadKey();


               
        }
    }
}
