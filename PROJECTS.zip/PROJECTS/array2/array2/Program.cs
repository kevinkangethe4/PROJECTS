﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myarr = new int[] { 12, 89, 80, 90 };
            int large = int.MinValue;
            int sec = int.MinValue;
            foreach (int i in myarr)
            {
                if (i > large)
                {
                    sec = large;
                    large = i;
                }
                else if (i > sec)
                    sec = i;
            }
            Console.WriteLine(sec);
            Console.ReadKey();
            
        }
        
    }
}
